'use strict';

const settings = {
    elements: {},
    spielfeldWidth: 500,
    spielfeldHeight: 500,
    timerID: false,
    intervalDelay: 30,
    drops:[],
    rotation:0,
    socket:false,
    io:false,
    snake: false
}

export default settings;
export let elements = settings.elements;